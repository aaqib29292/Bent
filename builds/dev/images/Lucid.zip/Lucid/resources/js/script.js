$(document).ready(function() {

  /* For the sticky navigation */
  $('.hero-text-box').waypoint(function(direction) {
    if (direction == "down")
    {
      $('nav').addClass('sticky');
    }
    else
    {
      $('nav').removeClass('sticky');
    }
  }, {
    offset: '60px;'
  });

  /* Navigation scroll*/
  $(function() {
    $('a[href*="#"]:not([href="#"])').click(function() {
      if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
        if (target.length) {
          $('html, body').animate({
            scrollTop: target.offset().top
          }, 1000);
          return false;
        }
      }
    });
  });

 /* Carousel slider */
 var owl = $("#owl-example");

 owl.owlCarousel({
     items : 2, //10 items above 1000px browser width
     itemsDesktop : [1000,2], //5 items between 1000px and 901px
     itemsDesktopSmall : [900,2], // betweem 900px and 601px
     itemsTablet: [600,1], //2 items between 600 and 0
     itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
 });

 // Custom Navigation Events

 $(".play").click(function(){
   owl.trigger('owl.play',1000); //owl.play event accept autoPlay speed as second parameter
 });
 $(".stop").click(function(){
   owl.trigger('owl.stop');
 });

 /* Maps */
  var map = new GMaps({
    div: '.map',
    lat: 38.7436056,
    lng: -9.05,
    zoom: 12
  });

  map.addMarker({
    lat: 38.7436056,
    lng: -9.15,
    title: 'Lima',
    infoWindow: {
      content: '<p>Our Lisbon HQ</p>'
    }
  });

});
